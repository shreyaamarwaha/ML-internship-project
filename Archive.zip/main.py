import pandas as pd
import matplotlib.pyplot as plt

# Function to read test and label files
def read_data(test_file, label_file):
    test_data = pd.read_csv(test_file)
    label_data = pd.read_csv(label_file)
    return test_data, label_data

# Function to plot time series with anomaly regions
def plot_time_series_with_anomaly(data, labels, save_path=None):
    # Plot the time series data
    plt.plot(data['timestamp_(min)'], data.drop(columns=['timestamp_(min)']))

    # Add anomaly regions
    for _, row in labels.iterrows():
        plt.axvspan(row['timestamp_(min)'], row['timestamp_(min)'], color='red', alpha=0.3, label='Anomaly Region')

    # Add labels and title
    plt.xlabel('Time')
    plt.ylabel('Value')
    plt.title('Time Series with Anomaly Regions')
    plt.legend()

    # Save the plot if save_path is provided
    if save_path:
        plt.savefig(save_path)
    else:
        plt.show()

# Example usage
test_file = "psm_test.csv"
label_file = "psm_test_label.csv"
test_data, test_label = read_data(test_file, label_file)
plot_time_series_with_anomaly(test_data, test_label, save_path='time_series_with_anomaly.png')
