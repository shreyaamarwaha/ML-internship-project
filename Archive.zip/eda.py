import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA

# Reading the data
data = pd.read_csv("psm_test.csv")

# Displaying basic information about the dataset
print("Shape of the dataset:", data.shape)
print("\nData types:")
print(data.dtypes)
print("\nSummary statistics:")
print(data.describe())

# Plotting histograms for each feature
data.hist(bins=20, figsize=(15, 15))
plt.suptitle('Histograms of Features', x=0.5, y=0.92, fontsize=16)
plt.show()

# Plotting line plots for each feature
data.plot(subplots=True, figsize=(15, 15))
plt.suptitle('Line Plots of Features', x=0.5, y=0.95, fontsize=16)
plt.show()

# Correlation matrix
correlation_matrix = data.corr()

# Plotting the correlation matrix as a heatmap
plt.figure(figsize=(12, 10))
plt.title('Correlation Heatmap')
plt.imshow(correlation_matrix, cmap='coolwarm', interpolation='nearest')
plt.colorbar()
plt.xticks(range(len(data.columns)), data.columns, rotation=90)
plt.yticks(range(len(data.columns)), data.columns)
plt.show()

# Check for missing values
missing_values = data.isnull().sum()
print("Missing Values:\n", missing_values)

# Box plot for outlier detection
plt.figure(figsize=(10, 6))
sns.boxplot(data=data)
plt.title("Boxplot of Features")
plt.show()

# Histogram for target variable
plt.figure(figsize=(8, 5))
sns.histplot(data=data, x='target', bins=20, kde=True)
plt.title("Distribution of Target Variable")
plt.xlabel("Target")
plt.ylabel("Frequency")
plt.show()

# Time series plot
plt.figure(figsize=(12, 6))
plt.plot(data['timestamp'], data['value'])
plt.title("Time Series Plot")
plt.xlabel("Timestamp")
plt.ylabel("Value")
plt.show()



# Fit PCA
pca = PCA(n_components=2)
principal_components = pca.fit_transform(data)

# Visualizing principal components
plt.figure(figsize=(8, 6))
plt.scatter(principal_components[:, 0], principal_components[:, 1], c=data['target'], cmap='viridis')
plt.title("PCA Visualization")
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.colorbar(label='Target')
plt.show()
